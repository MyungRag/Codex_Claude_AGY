import {runner} from './agent-client.js?v=0.10.0';
export const escapeHTML=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const e=escapeHTML;
export const names={codex:'Codex',claude:'Claude',agy:'Antigravity'};
const statusNames={queued:'요청 대기',running:'응답 생성 중',succeeded:'응답 완료',failed:'응답 실패',cancelled:'취소됨',interrupted:'실행 중단'};
const kinds={review:'기획 검토',organize:'노드 독립 검토','organize-merge':'주 AI 노드 통합',questions:'질문 독립 검토','questions-merge':'주 AI 질문 통합',conflicts:'결정 충돌 검토',handoff:'업무 분담','development-build':'코드 구현','development-audit':'코드 검토','development-analysis':'분석·총괄',probe:'연결 확인'};
const duration=(start,end)=>{const seconds=Math.max(0,Math.floor(((end?Date.parse(end):Date.now())-Date.parse(start))/1000));return Number.isFinite(seconds)?`${Math.floor(seconds/60)}분 ${seconds%60}초`:'—';};
const number=value=>Number.isFinite(value)?value.toLocaleString('ko-KR'):'미제공';
export const callRole=call=>call.kind?.endsWith('-merge')||call.role==='overall-lead'?'총괄 · 통합':call.kind==='development-build'?'구현':call.kind==='development-audit'?'검토':'기획 · 분석';
export function mergeActivity(state={},jobs=[],projectId){
 const calls=new Map((state.aiCalls||[]).map(c=>[c.jobId||c.id,{...c}]));
 for(const job of jobs.filter(j=>j.context?.projectId===projectId)){
  const previous=calls.get(job.id);calls.set(job.id,{...previous,...job,...(previous?.status==='failed'?{status:'failed',error:previous.error}:{}),taskId:previous?.taskId||job.context?.taskId,role:previous?.role||job.context?.role});
 }
 return [...calls.values()].sort((a,b)=>Date.parse(a.requestedAt||a.createdAt)-Date.parse(b.requestedAt||b.createdAt));
}
export function usageTotals(calls){
 const reported=calls.filter(c=>Number.isFinite(c.usage?.totalTokens));
 return {calls:calls.length,failed:calls.filter(c=>c.status==='failed').length,reported:reported.length,tokens:reported.length?reported.reduce((s,c)=>s+c.usage.totalTokens,0):null,milliseconds:calls.reduce((sum,c)=>sum+(c.startedAt?Math.max(0,Date.parse(c.finishedAt||new Date().toISOString())-Date.parse(c.startedAt)):0),0)};
}
export function monitorHTML({calls=[],state={},plan,tab='live',error='',observedAt,config={}}={}){
 const active=calls.filter(c=>c.status==='running'),waiting=calls.filter(c=>c.status==='queued'),totals=usageTotals(calls);
 const taskName=id=>state.tasks?.find(t=>t.id===id)?.title||plan?.nodes?.find(n=>n.id===id)?.title||'프로젝트 전체';
 const heading=`<div class="monitor-heading"><div><span class="eyebrow">AGENTS AT WORK</span><h2>AI 실행 확인</h2><p>현재 실행 ${active.length}개 · 대기 ${waiting.length}개 · ${active.length>1?'여러 AI가 병렬 실행 중':active.length?'AI 응답을 기다리고 있습니다':'진행 중인 AI 호출 없음'}</p></div><span class="monitor-sync ${error?'is-stale':''}">${error?'연결 확인 필요':observedAt?'최근 확인 '+new Date(observedAt).toLocaleTimeString('ko-KR'):'실행기 연결 후 확인'}</span></div><nav class="dev-tabs" aria-label="AI 실행 세부 보기"><button class="button ${tab==='live'?'active':''}" data-monitor-tab="live" aria-pressed="${tab==='live'}">실시간 역할·작업</button><button class="button ${tab==='usage'?'active':''}" data-monitor-tab="usage" aria-pressed="${tab==='usage'}">호출·사용량 기록</button></nav>${error?`<p class="dev-warning">${e(error)} 마지막으로 확인한 상태입니다. 진행·정지 여부를 단정할 수 없습니다.</p>`:''}`;
 const cards=Object.keys(names).map(agent=>{
  const own=calls.filter(c=>c.agent===agent),current=own.findLast(c=>c.status==='running'),queued=own.filter(c=>c.status==='queued'),last=own.at(-1),stats=usageTotals(own);
  const roles=[config.lead===agent?'총괄':'',config.roles?.builder===agent?'구현':'',config.roles?.auditor===agent?'검토':'',config.roles?.challenger===agent?'분석':''].filter(Boolean).join(' · ');
  return `<article class="agent-station agent-${agent} ${current&&!error?'is-running':''}"><div class="agent-station-top"><span class="agent-orb" aria-hidden="true"></span><span>${e(current?callRole(current):roles||'참여 AI')}</span><b>${current?'실행 중':queued.length?'대기열':'대기'}</b></div><h3>${names[agent]}</h3><p class="station-task">${e(current?kinds[current.kind]||current.kind:queued.length?'같은 AI의 앞선 요청을 기다립니다':'현재 실행 중인 요청 없음')}</p>${current?`<button class="monitor-node-link" data-monitor-node="${e(current.taskId||'')}">${e(taskName(current.taskId))} ↗</button><p class="monitor-time">${duration(current.startedAt||current.createdAt)} <small>경과</small></p><p class="dev-helper">모델: ${e(current.actualModel||current.settings?.model||'기본 모델 · 보고 대기')}</p><p class="dev-helper">${current.activity?.lastOutputAt?'최근 출력 '+duration(current.activity.lastOutputAt)+' 전':'아직 출력 신호 없음'} · ${e(current.progress?.message||current.progress?.phase||'응답 수신 대기')}</p>`:`<p class="dev-helper">${last?'최근 요청: '+e(statusNames[last.status]||last.status):'이 프로젝트의 호출 기록 없음'}</p>`}<div class="station-stats"><span>호출 <b>${stats.calls}</b></span><span>토큰 <b>${number(stats.tokens)}</b></span><span>대기 <b>${queued.length}</b></span></div></article>`;
 }).join('');
 const usage=`<section class="monitor-total"><strong>${number(totals.tokens)}</strong><span>보고된 토큰 합계</span><p>호출 ${totals.calls}회 · 실패 ${totals.failed}회 · 사용량 보고 ${totals.reported}/${totals.calls}회</p><small>미제공 사용량은 합계에 포함되지 않습니다. 캐시·추론 토큰을 중복 합산하지 않습니다.</small></section><div class="monitor-usage">${Object.keys(names).map(agent=>{const stats=usageTotals(calls.filter(c=>c.agent===agent));return `<article class="agent-station agent-${agent}"><h3>${names[agent]}</h3><div class="station-stats"><span>호출 <b>${stats.calls}회</b></span><span>호출 시간 <b>${Math.floor(stats.milliseconds/60000)}분</b></span><span>토큰 <b>${number(stats.tokens)}</b></span></div><meter min="0" max="${Math.max(1,totals.tokens||0)}" value="${stats.tokens||0}" aria-label="${names[agent]} 보고된 토큰 비중"></meter><small>사용량 보고 ${stats.reported}/${stats.calls}회</small></article>`;}).join('')}</div>`;
 const list=`<section class="dev-card"><h3>${tab==='live'?'최근 호출과 작업 연결':'호출별 기록'}</h3><div class="dev-table-scroll"><table><thead><tr><th>AI · 역할</th><th>작업</th><th>상태</th><th>시간</th><th>토큰</th></tr></thead><tbody>${calls.slice(tab==='live'?-8:-100).reverse().map(c=>`<tr><td>${e(names[c.agent]||c.agent)}<br><small>${e(callRole(c))}</small></td><td><button class="monitor-node-link" data-monitor-node="${e(c.taskId||'')}">${e(taskName(c.taskId))}</button><small>${e(kinds[c.kind]||c.kind)}</small></td><td>${e(statusNames[c.status]||c.status)}${c.error?`<small>${e(c.error)}</small>`:''}</td><td>${duration(c.startedAt,c.finishedAt)}</td><td>${number(c.usage?.totalTokens)}</td></tr>`).join('')||'<tr><td colspan="5">실제 AI 요청이 시작되면 기록됩니다.</td></tr>'}</tbody></table></div></section>`;
 return `<section class="execution-monitor">${heading}${state.status==='running'?`<p class="monitor-host" role="status">개발 실행 중 · ${(state.tasks||[]).filter(t=>t.status==='running').map(t=>e(t.title)+' — '+e(t.phase||'작업 준비')).join(' / ')||'다음 작업·통합 결과 준비 중'}</p>`:''}${tab==='live'?`<div class="agent-stations">${cards}</div><p class="dev-helper">같은 AI는 한 번에 한 요청을 처리합니다. 서로 다른 AI의 독립 요청은 동시에 실행합니다. 출력이 없는 시간은 작업 중단의 확정 신호가 아닙니다.</p>`:usage}${list}</section>`;
}
// One subscription per mounted surface; no CLI availability probe on each poll.
export function watchActivity(projectId,onUpdate,{client=runner,interval=1500}={}){
 let closed=false,timer;
 const poll=async()=>{try{if(client.token){const data=await client.request('/api/agents/activity');if(!closed)onUpdate({...data,error:''});}}catch(error){if(!closed)onUpdate({error:error.message});}finally{if(!closed)timer=setTimeout(poll,interval);timer?.unref?.();}};
 void poll();return()=>{closed=true;clearTimeout(timer);};
}
export function mountActivityBanner(root,projectId){
 return watchActivity(projectId,data=>{if(!root.isConnected)return;const calls=(data.jobs||[]).filter(j=>j.context?.projectId===projectId&&j.status==='running');root.innerHTML=`<a class="global-ai-status" href="#${e(projectId)}/activity"><span class="monitor-dot ${calls.length&&!data.error?'is-running':''}"></span><strong>AI 실행 ${data.error?'확인 필요':calls.length+'개'}</strong><span>${data.error?'실행기 연결 확인 중':calls.map(c=>names[c.agent]+' · '+(kinds[c.kind]||c.kind)).join(' / ')||'현재 실행 중인 호출 없음'}</span><b>실행 확인 ↗</b></a>`;});
}
